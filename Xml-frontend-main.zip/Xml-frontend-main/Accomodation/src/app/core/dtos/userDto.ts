export interface UserProfileDto{
  id:number,
  name: string,
  surname : string,
  email  :  string,
  password  : string,
  cityId : string


}
