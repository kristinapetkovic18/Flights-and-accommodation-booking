import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accommodation-homepage',
  templateUrl: './accommodation-homepage.component.html',
  styleUrls: ['./accommodation-homepage.component.css']
})
export class AccommodationHomepageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
