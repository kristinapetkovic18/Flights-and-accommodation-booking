

export interface User{
  id: number,
  name: string,
  surname: string,
  email: string,
  password: string,
  address: string,
  city: string,
  country: string,
  mobile: string,
}
