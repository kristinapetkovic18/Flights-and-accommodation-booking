﻿namespace FlightService.Model
{
    public enum UserType
    {
         NK, H, G, OK, A

    }
}