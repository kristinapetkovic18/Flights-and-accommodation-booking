﻿namespace XML.Model
{
    public class City : Entity
    {
        public string Name { get; set; }
        public string ZipCode { get; set; }

    }
}
