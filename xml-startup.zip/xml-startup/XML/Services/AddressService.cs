﻿using XML.Core;

namespace XML.Services
{
    public class AddressService : IAddressService
    {
    }
}
