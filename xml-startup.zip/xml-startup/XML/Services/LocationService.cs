﻿using XML.Core;

namespace XML.Services
{
    public class LocationService : ILocationService
    {
    }
}
