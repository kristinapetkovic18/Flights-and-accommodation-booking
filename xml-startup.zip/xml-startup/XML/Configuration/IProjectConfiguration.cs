﻿namespace XML.Configuration
{
    public interface IProjectConfiguration
    {
    }
}
