﻿using XML.Model;

namespace XML.Core
{
    public interface IAddressRepository : IBaseRepository<Address>
    {
    }
}
