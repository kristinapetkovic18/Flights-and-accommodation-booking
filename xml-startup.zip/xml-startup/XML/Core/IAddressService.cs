﻿namespace XML.Core
{
    public interface IAddressService
    {
    }
}
