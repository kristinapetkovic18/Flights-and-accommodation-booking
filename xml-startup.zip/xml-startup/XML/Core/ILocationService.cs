﻿namespace XML.Core
{
    public interface ILocationService
    {
    }
}
