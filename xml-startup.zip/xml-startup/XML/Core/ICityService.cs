﻿namespace XML.Core
{
    public interface ICityService 
    {
        //City GetCityById(long id);
    }
}
