﻿namespace UserService.Configuration
{
    public interface IProjectConfiguration
    {
    }
}
