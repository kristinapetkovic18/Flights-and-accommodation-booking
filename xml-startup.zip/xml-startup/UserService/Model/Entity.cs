﻿namespace UserService.Model
{
    public class Entity
    {
        public long Id { get; set; }
        public bool Deleted { get; set; }
    }
}
