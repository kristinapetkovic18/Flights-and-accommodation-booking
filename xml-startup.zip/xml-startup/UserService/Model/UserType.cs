﻿namespace UserService.Model
{
    public enum UserType
    {
        Host, Guest
    }
}
