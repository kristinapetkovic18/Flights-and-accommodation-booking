﻿namespace ReservationService.Configuration
{
    public interface IProjectConfiguration
    {
    }
}
